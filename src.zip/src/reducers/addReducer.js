import fakeStoreApi from "../APIS/fakeStoreApi";

const INITIAL_STATE = {
  item: [],
  items: [],
  products: [],
  product: [],
  realitems: [],
  totalQuantity: 0,
};
export const fetchProducts = () => async (dispatch) => {
  const response = await fetch("https://jsonplaceholder.typicode.com/users");
  const data = await response.json();
  dispatch({ type: "FETCH_PRODUCTS", payload: data });
};
export const selectedProduct = (id) => async (dispatch) => {
  console.log(id, "IDDDDDS");
  const response = await fetch(
    `https://jsonplaceholder.typicode.com/users/${id}`
  );
  const data = await response.json();
  dispatch({ type: "SELECTED_PRODUCT", payload: data });
};
function addReducer(state = INITIAL_STATE, action) {
  switch (action.type) {
    case "ADD_ITEM":
      console.log(action, "ahghsgda");
      return { ...state, item: [...state.item, action.name] };
    case "REMOVE_ITEM":
      console.log(action, "REMOPVE");
      return {
        ...state,
        item: state.item.filter((inditem) => inditem !== action.name),
      };
    case "RESET_ITEM":
      console.log(action, "REMOPVE");
      return { ...state, item: [] };
    case "FETCH_PRODUCTS":
      console.log(action, "REMOPVE");
      return {
        ...state,
        products: action.payload,
      };
    case "SELECTED_PRODUCT":
      console.log(action, "REMOPVE");
      return {
        ...state,
        product: action.payload,
      };
    case "REMOVE_PRODUCT":
      console.log(action, "REMOPVE");
      return {
        ...state,
        product: {},
      };

    case "ADD_PRODUCT":
      console.log("Addd");
      const newItem = action.payload;
      const existingItem = state.items.find((item) => item.id === newItem.id);
      console.log(existingItem, "exx");
      state.totalQuantity++;
      if (!existingItem) {
        return {
          ...state,
          items: [
            {
              id: newItem.id,
              name: newItem.name,
              quantity: 1,
            },
          ],
        };
      } else {
        return {
          ...state,
          items: [
            {
              ...state,
              quantity: existingItem.quantity++,
            },
          ],
        };
      }

    default:
      return state;
  }
}

export default addReducer;
