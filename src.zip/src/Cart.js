import Modal from "./Modal";
import { useSelector } from "react-redux";
const Cart = (props) => {
  const cartproducts = useSelector((state) => state.add);
  console.log(cartproducts.products, "PPP");
  return (
    <Modal onClose={props.onClose}>
      {cartproducts.products.map((data) => {
        return (
          <>
            <p>{data.name}</p>
            <p>quantity:{data.quantity}</p>
          </>
        );
      })}
    </Modal>
  );
};

export default Cart;
