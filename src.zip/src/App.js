import logo from "./logo.svg";
import "./App.css";
import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchProducts } from "./reducers/addReducer";
import ProductDetail from "./components/ProductDetail";
import { Link, useParams } from "react-router-dom";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { FaCartArrowDown } from "react-icons/fa";
import Cart from "./Cart";
function App() {
  const [name, setName] = useState("");
  const [searchTerm, setSearchterm] = useState("");
  const [detail, setDetail] = useState(false);
  const dispatch = useDispatch();
  const [cartIsShown, setCartIsShown] = useState(false);

  const showCartHandler = () => {
    setCartIsShown(true);
  };

  const hideCartHandler = () => {
    setCartIsShown(false);
  };

  // const { productId = "1" } = useParams();
  const data = useSelector((state) => state.add);
  // const products = useSelector((state) => state.add.products);
  // console.log(productId, "Ppsppppppppppppppppp");
  useEffect(() => {
    dispatch(fetchProducts());
  }, []);

  const handleChange = (e) => {
    setName(e.target.value);
  };

  //   console.log(name);
  // if (data.length == 0) {
  //   return <p>No data</p>;
  // }

  const Submithandler = () => {
    dispatch({ type: "ADD_ITEM", name });
    setName("");
  };
  const handleSearch = (e) => {
    setSearchterm(e.target.value);
  };

  const reset = () => {
    dispatch({ type: "RESET_ITEM", searchTerm });
  };

  return (
    <div className="App">
      {cartIsShown && <Cart onClose={hideCartHandler} />}
      <header className="headerstyle">
        <h1>Shopping cart</h1>
        <FaCartArrowDown
          onClick={showCartHandler}
          style={{ height: "57px", width: "36px" }}
        ></FaCartArrowDown>
      </header>
      {data.loading && <p>loading</p>}
      <input value={searchTerm} onChange={(e) => handleSearch(e)} />
      {/* <button onClick={() => submitSerach()}>search</button> */}
      <button onClick={() => reset()}>reset</button>
      <input value={name} onChange={handleChange} />
      <button onClick={Submithandler}>Add</button>

      {data.item.length === 0 && <p>no item</p>}
      {data?.item
        .filter((item) => item.toLowerCase().includes(searchTerm))
        .map((dta, i) => {
          return (
            <div>
              {dta}
              <button
                onClick={() => dispatch({ type: "REMOVE_ITEM", name: dta })}
              >
                Remove
              </button>
            </div>
          );
        })}

      <Routes>
        <Route path="/products/:productId" element={<ProductDetail />} exact />
      </Routes>
      <div className="container">
        {data.products.map((prdt, i) => {
          return (
            <div className="item">
              <Link to={`/products/${prdt.id}`}>{prdt.name}</Link>

              <button
                onClick={() => dispatch({ type: "ADD_PRODUCT", payload: prdt })}
              >
                ADD TO CART
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default App;

// import React from "react";
// import Cart from "./components/Cart";
// import { Layout } from "./components/Layout";
// import { MainHeader } from "./components/MainHeader";
// import Products from "./components/Products";
// import { useSelector } from "react-redux";
// import "./App.css";
// function App() {
//   const hide = useSelector((state) => state.ui.toggleVisible);
//   return (
//     <Layout>
//       {hide && <Cart />}
//       <Products />
//     </Layout>
//   );
// }

// export default App;
